from django import forms
from app.modelo.models import Cliente

class FormularioCliente(forms.ModelForm):
    
    class Meta:
        model=Cliente
        fields=["cedula", "nombres", "apellidos", "genero"]
