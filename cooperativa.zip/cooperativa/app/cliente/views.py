from django.shortcuts import render, redirect

# Create your views here.

from django.http import HttpResponse

from .forms  import FormularioCliente
from app.modelo.models import Cliente
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required

def principal(request):
    usuario=request.user
    print('xxxxxxxxxxxx')
    print(usuario)
    if usuario.has_perm('modelo.add_cliente'):
        print('tienen el permiso')
        listaClientes= Cliente.objects.all().filter(estado=True).order_by('apellidos')
        context={
            'lista':listaClientes
        }
        return render(request, 'cliente/principal_cliente.html', context)
    else:
        return render(request, 'login/acceso_prohibido.html')
        


#
#user=request.user
#user.get_all_permissions()
#user.get_group_permissions()
#user.has_perms()
#user.has_perm()
#user.user_permissions.remove()
#user.is_member()
#------------------------------------


def saludar(request):
    return HttpResponse('Hola Clase')

@login_required
def crear(request):
    formulario=FormularioCliente(request.POST)
    if request.method== 'POST': 
        if formulario.is_valid():
            datos=formulario.cleaned_data
            cliente=Cliente()
            cliente.cedula=datos.get('cedula')
            cliente.nombres=datos.get('nombres')
            cliente.apellidos=datos.get('apellidos')
            cliente.genero=datos.get('genero')
            cliente.save()
            return redirect(principal)
            
    context={
      'f': formulario,
      'mensaje':'Bienvenidos',
    }
    return render(request, 'cliente/crear_cliente.html', context)


@login_required
def modificar(request):
    dni= request.GET['cedula']
    cliente= Cliente.get(cedula=dni)
    if request.method=='POST':
        formulario= FormularioCliente(request.POST)
        if formulario.is_valid():
            datos=formulario.cleaned_data
            cliente.cedula=datos.get('cedula')
            cliente.nombres=datos.get('nombres')
            cliente.apellidos=datos.get('apellidos')
            cliente.genero=datos.get('genero')
            cliente.save()
            return redirect(principal)
    else:
        formulario= FormularioCliente(instance=cliente)
        context={
            'f': formulario,
            'mensaje':'Bienvenidos',
        }
    return render(request, 'cliente/crear_cliente.html', context)

@login_required
def eliminar(request):
    dni= request.GET['cedula']
    cliente= Cliente.objects.get(cedula=dni)
    cliente.estado=False
    
    cliente.save()
    return redirect(principal)

