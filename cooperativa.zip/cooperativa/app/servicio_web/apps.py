from django.apps import AppConfig


class ServicioWebConfig(AppConfig):
    name = 'servicio_web'
