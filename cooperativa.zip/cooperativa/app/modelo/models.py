from django.db import models

# Create your models here.

class Cliente(models.Model):
    listaGenero= (
        ('f', 'Femenino'),
        ('m', 'Masculino') 
    )
    cedula=models.CharField(max_length=10)
    apellidos=models.CharField(max_length=25)
    nombres=models.CharField(max_length=25)
    genero=models.CharField(max_length=15, choices=listaGenero)
    telefono= models.CharField(max_length=11)
    direccion= models.CharField(max_length=30)
    correo=models.EmailField(max_length=35)
    edad=models.CharField(max_length=3)
    correoAlterno= models.CharField(max_length=35)
    telefonoAlterno= models.CharField(max_length=11)
    estado=models.BooleanField(default=True)

class Banco(models.Model):
    codigo= models.CharField(max_length=20)
    
        
class Cuenta(models.Model):
    cuenta=models.CharField(max_length=11)
    nombres= models.CharField(max_length=25)
    apellidos= models.CharField(max_length=25)
    cedula= models.CharField(max_length=10)
    saldo= models.CharField(max_length=7)
    
class Transaccion(models.Model):
    fecha= models.DateField(auto_now=False)
    codigoOperacion=models.CharField(max_length=5)
    retiros= models.CharField(max_length=7)
    depositos=models.CharField(max_length=7)
    saldo=models.CharField(max_length=7)
    