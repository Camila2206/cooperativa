from django.contrib import admin

# Register your models here.
from .models import Cliente 
from .models import Banco
from .models import Cuenta
from .models import Transaccion

class AdminCliente(admin.ModelAdmin):
    list_display= ["cedula", "apellidos", "nombres", "genero", "telefono", "direccion", "correo", "edad", "correoAlterno", "telefonoAlterno"]
    list_editable=["apellidos", "nombres", "genero", "telefono", "direccion", "correo", "correoAlterno", "telefonoAlterno" ]
    list_filter=["apellidos", "genero"]
    search_fields=["cedula"]
    class Meta:
        model=Cliente
admin.site.register(Cliente, AdminCliente)

class AdminBanco(admin.ModelAdmin):
    list_display=["codigo"]
    search_fields=["codigo"]
        
    class Meta:
        model=Banco
        
admin.site.register(Banco, AdminBanco)

class AdminCuenta(admin.ModelAdmin):
    list_display=["cuenta", "nombres", "apellidos", "cedula", "saldo"]
    search_fields=["cuenta"]
    list_filter=["cuenta", "cedula"]
    class Meta:
        model=Cuenta
admin.site.register(Cuenta, AdminCuenta)

class AdminTransacion(admin.ModelAdmin):
    list_display=["fecha", "codigoOperacion", "retiros", "depositos", "saldo"]
    search_fields=["codigoOperacion"]
admin.site.register(Transaccion, AdminTransacion)